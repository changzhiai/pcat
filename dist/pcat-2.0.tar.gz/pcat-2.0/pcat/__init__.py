# -*- coding: utf-8 -*-
"""
Created on Fri Mar 12 21:30:13 2021

@author: changai
"""

#import parent dirs for local
import sys
sys.path.append("..")